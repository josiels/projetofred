<?php
sleep(2); // dormindo por 2 segundos para demorar um pouco mais

echo "minha lógica foi executada! e você mandou os seguintes parametros";
print_r($_REQUEST); // imprimindo conteudo do $_GET e $_POST